class validation {
    static NameRegx = /^[A-Za-z\'\s\.\:\-]+$/;
    static EmailRegx = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
}

export default validation;
